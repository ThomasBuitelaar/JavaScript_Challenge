<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Kalender</title>	
	<link rel="icon" type="img/png" href="<?= URL . '/public/img/icon.png' ?>" size="64x64">
	<link rel="stylesheet" href="<?= URL . '/public/css/style.css' ?>">
	<script src="https://use.fontawesome.com/00fe25a6ad.js"></script>
</head>
<body>
