<div id="container">
  <h1>Dit is student/delete</h1>
</div>
